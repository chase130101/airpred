# configuration file for data_setup.R 

POLLUTION_DATA_PATH   <- "../data/assembled_data.rds"
CENSUS_DATA_PATH      <- "../data/sensor_locations_with_census.csv"
FULL_SAVE_RESULT_PATH < "../data/data_to_impute.csv"
